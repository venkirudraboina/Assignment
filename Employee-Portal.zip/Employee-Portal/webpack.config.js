const webpack = require("webpack");
var config = {
   entry: {
	      "index": "./src/components/main.js",
	},
   output: {
      filename: "./dist/[name].js"
   },
   devServer: {
      inline: true,
      port: 7070
   },
   devtool: "#eval-source-map",
   plugins: [
	   new webpack.optimize.UglifyJsPlugin({
		      include: /\.min\.js$/,
		      minimize: true
		    })
	],
   module: {
      loaders: [
         {
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            query: {
               presets: ['es2015', 'react']
            }
         }
      ]
   }
}
module.exports = config;