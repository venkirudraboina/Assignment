const qwest = require('qwest');
const ServiceUrl = require('../constants/ServicesUrl.jsx');

var SnapshotsApi = {

    getAllSnapshots: function(investigationId, token) {
        qwest.setDefaultDataType('json');
        qwest.setDefaultOptions({
            timeout: 180000,
            contentType: false,
            cache: true,
            headers: {
              'Authorization': "JWT "+ token,
            },
          });
        return new Promise((resolve, reject) => {
          qwest.get(`${ServiceUrl.default.SNAPSHOTS_GET}?investigation_id=${investigationId}`)
            .then((xhr, response) => {
              resolve(response,xhr);
            })
        });
      },

    createSnapshot: function(investigationId, token) {
        qwest.setDefaultDataType('json');
        qwest.setDefaultOptions({
            timeout: 180000,
            contentType: false,
            cache: true,
            headers: {
              'Authorization': "JWT "+ token,
            },
          });
        return new Promise((resolve, reject) => {

          qwest.get(`${ServiceUrl.default.SNAPSHOTS_ADDNEW}?investigation_id=${investigationId}`)
            .then((xhr, response) => {
              resolve(response,xhr);
            })
        });
      },
      updateSnapShot: function(snapShotObj, token,investigationId) {
            qwest.setDefaultDataType('json');
            qwest.setDefaultOptions({
                timeout: 180000,
                contentType: false,
                cache: true,
                headers: {
                  'Authorization': "JWT "+ token,
                },
              });
            return new Promise((resolve, reject) => {

              qwest.put(`${ServiceUrl.default.SNAPSHOTS_UPDATE}`, JSON.stringify({
                      snapShotObj: snapShotObj,
                      investigation_id:investigationId
                   }))
                .then((xhr, response) => {
                  resolve(response,xhr);
                })
            });
       },

};
module.exports = SnapshotsApi;
