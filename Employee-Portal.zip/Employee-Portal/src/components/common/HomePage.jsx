import React from 'react';
import LoginPage from './LoginPage.jsx';


class HomePage extends React.Component {
   render() {
      return (
        <LoginPage/>
      );
   }
}

export default HomePage;
