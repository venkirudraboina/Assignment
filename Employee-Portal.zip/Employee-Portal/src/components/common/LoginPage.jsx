import React from 'react';

class LoginPage extends React.Component {
   constructor(props) {
       super(props);
       this.state = {userName: "",passWord: ""};
       this.changeUserName = this.changeUserName.bind(this);
       this.changePassword = this.changePassword.bind(this);
   }

   changeUserName(event) {
      this.setState({userName: event.target.value});
   }

   changePassword(event) {
      this.setState({passWord: event.target.value});
   }

   onLogin() {
        var userName=this.state.userName;
        var passWord=this.state.passWord;

        if(userName=="")
        {
            alert("Please enter username");
            return;
        }

        if(passWord=="")
        {
            alert("Please enter password");
            return;
        }

        if(userName=='venki' && passWord=='venki'){
            alert("Login success");
        }else{
            alert("Invalid Login credentials");
        }
   }


   render() {
      return (
        <div className="login-div">
            <div className="login-page">
              <div className="form">
                <form className="login-form">
                  <input type="text" placeholder="username" value={this.state.userName} onChange={this.changeUserName}/>
                  <input type="password" placeholder="password" value={this.state.passWord} onChange={this.changePassword}/>
                  <button type="submit" onClick={(e) => this.onLogin(e)}>login</button>
                </form>
              </div>
            </div>
        </div>
      );
   }
}

export default LoginPage;
