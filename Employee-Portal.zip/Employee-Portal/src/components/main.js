import React from 'react';
import ReactDOM from 'react-dom';
import HomPage from './common/HomePage.jsx';

ReactDOM.render(<HomPage/>, document.getElementById('app'));
